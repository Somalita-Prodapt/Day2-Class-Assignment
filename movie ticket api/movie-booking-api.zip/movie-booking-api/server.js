const express = require("express");
const fs = require("fs").promises;
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const app = express();
const PORT = 3000;
const BOOKINGS_FILE = path.join(__dirname,"data","bookings.json");
const INVENTORY_FILE = path.join(__dirname,"data","seats-inventory.json");
app.use(express.json());
app.get('/bookings', async (req,res)=>{try{const d=JSON.parse(await fs.readFile(BOOKINGS_FILE,'utf-8'));res.json(d);}catch(e){res.status(500).json({error:e.message});}});
async function rb(){return JSON.parse(await fs.readFile(BOOKINGS_FILE,'utf-8'));}
async function ri(){return JSON.parse(await fs.readFile(INVENTORY_FILE,'utf-8'));}
async function wb(d){await fs.writeFile(BOOKINGS_FILE,JSON.stringify(d,null,2));}
async function wi(d){await fs.writeFile(INVENTORY_FILE,JSON.stringify(d,null,2));}
app.post('/bookings', async (req,res)=>{try{const {movieName,showTime,seatNumber,customerName}=req.body; if(!movieName||!showTime||seatNumber===undefined||!customerName) return res.status(400).json({error:'All fields required'}); const bookings=await rb(); const inventory=await ri(); if(bookings.find(b=>b.movieName===movieName&&b.showTime===showTime&&b.seatNumber===seatNumber)) return res.status(409).json({error:'Seat already booked'}); const show=inventory.find(s=>s.movieName===movieName&&s.showTime===showTime); if(!show) return res.status(404).json({error:'Show not found'}); if(show.availableSeats<=0) return res.status(400).json({error:'Sold out'}); const booking={id:uuidv4(),movieName,showTime,seatNumber,customerName}; const old=show.availableSeats; try{show.availableSeats--; await wi(inventory); bookings.push(booking); await wb(bookings); res.status(201).json(booking);}catch(err){show.availableSeats=old; await wi(inventory); throw err;}}catch(e){res.status(500).json({error:e.message});}});
app.delete('/bookings/:id', async (req,res)=>{try{const bookings=await rb(); const inventory=await ri(); const b=bookings.find(x=>x.id===req.params.id); if(!b) return res.status(404).json({error:'Booking not found'}); const show=inventory.find(s=>s.movieName===b.movieName&&s.showTime===b.showTime); if(show) show.availableSeats++; await wi(inventory); await wb(bookings.filter(x=>x.id!==b.id)); res.json({message:'Booking cancelled'});}catch(e){res.status(500).json({error:e.message});}});
app.listen(PORT,()=>console.log(`Running on ${PORT}`));